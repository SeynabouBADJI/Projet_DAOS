package com.uasz.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionDaosApplicationTests {

	@Test
	void contextLoads() {
	}

}
